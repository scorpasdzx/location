pub mod ques3{
    pub fn location(){
        println!("I am sending this file from an external library");
    }
}